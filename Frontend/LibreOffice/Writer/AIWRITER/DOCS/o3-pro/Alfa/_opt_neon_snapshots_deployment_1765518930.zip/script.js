(function () {
  'use strict';

  function qs(selector, scope) {
    return (scope || document).querySelector(selector);
  }

  function qsa(selector, scope) {
    return Array.prototype.slice.call((scope || document).querySelectorAll(selector));
  }

  function showToast(message) {
    var toast = qs('#toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('active');
    setTimeout(function () {
      toast.classList.remove('active');
    }, 2600);
  }

  function initMobileNav() {
    var toggle = qs('.menu-toggle');
    var mobileNav = qs('.navbar-links-mobile');
    if (!toggle || !mobileNav) return;
    toggle.addEventListener('click', function () {
      mobileNav.classList.toggle('active');
    });
    qsa('.navbar-links-mobile .navbar-link').forEach(function (link) {
      link.addEventListener('click', function () {
        mobileNav.classList.remove('active');
      });
    });
  }

  function scrollToSection(id) {
    var el = document.getElementById(id);
    if (!el) return;
    var rect = el.getBoundingClientRect();
    var offset = window.pageYOffset + rect.top - 72;
    window.scrollTo({ top: offset, behavior: 'smooth' });
  }

  function initSidebarNav() {
    var items = qsa('.sidebar-item');
    if (!items.length) return;
    items.forEach(function (item) {
      item.addEventListener('click', function () {
        var target = item.getAttribute('data-target');
        if (target) {
          scrollToSection(target);
        }
      });
    });

    var sections = qsa('.report-section');
    if (!('IntersectionObserver' in window) || !sections.length) return;

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var id = entry.target.id;
          items.forEach(function (btn) {
            if (btn.getAttribute('data-target') === id) {
              btn.classList.add('current');
            } else {
              btn.classList.remove('current');
            }
          });
        }
      });
    }, {
      root: null,
      rootMargin: '-40% 0px -50% 0px',
      threshold: 0
    });

    sections.forEach(function (section) {
      observer.observe(section);
    });
  }

  function initDiagramZoom() {
    var openBtn = qs('#openDiagramZoom');
    var modal = qs('#diagramZoomModal');
    if (!openBtn || !modal) return;

    var content = qs('.modal-content', modal);

    function openModal() {
      modal.classList.add('active');
      modal.removeAttribute('hidden');
    }

    function closeModal() {
      modal.classList.remove('active');
      modal.setAttribute('hidden', '');
    }

    openBtn.addEventListener('click', function () {
      openModal();
    });

    modal.addEventListener('click', function (e) {
      if (e.target === modal) {
        closeModal();
      }
    });

    var closeBtn = qs('.modal-close', modal);
    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        closeModal();
      });
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !modal.hasAttribute('hidden')) {
        closeModal();
      }
    });

    if (content) {
      content.addEventListener('click', function (e) {
        e.stopPropagation();
      });
    }
  }

  function initCopyButtons() {
    var buttons = qsa('.copy-btn');
    if (!buttons.length || !navigator.clipboard) return;

    buttons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var pre = btn.closest('.card').querySelector('pre code');
        if (!pre) return;
        var text = pre.textContent;
        navigator.clipboard.writeText(text).then(function () {
          showToast('Kod został skopiowany do schowka.');
        }).catch(function () {
          showToast('Nie udało się skopiować kodu.');
        });
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initMobileNav();
    initSidebarNav();
    initDiagramZoom();
    initCopyButtons();
  });
})();
